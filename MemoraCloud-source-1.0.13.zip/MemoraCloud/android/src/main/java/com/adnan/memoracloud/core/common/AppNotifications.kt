package com.adnan.memoracloud.core.common

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.adnan.memoracloud.R
import com.adnan.memoracloud.presentation.MainActivity
import com.adnan.memoracloud.core.update.UpdateSkipReceiver

class AppNotifications(
    private val context: Context
) {

    @SuppressLint("MissingPermission")
    fun notifyFailure(title: String, message: String) {
        if (!hasPermission()) return
        val notification = NotificationCompat.Builder(context, CHANNEL_FAILURES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setContentIntent(screenIntent(DESTINATION_TRANSFERS, REQUEST_FAILURE))
            .setAutoCancel(true)
            .build()
        runCatching {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_FAILURE, notification)
        }
    }

    @SuppressLint("MissingPermission")
    fun notifyBackupResult(title: String, message: String) {
        if (!hasPermission()) return
        val notification = NotificationCompat.Builder(context, CHANNEL_BACKUP)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setContentIntent(screenIntent(DESTINATION_TRANSFERS, REQUEST_BACKUP))
            .setAutoCancel(true)
            .build()
        runCatching {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_BACKUP, notification)
        }
    }

    @SuppressLint("MissingPermission")
    fun notifyUpdate(title: String, message: String, version: String) {
        if (!hasPermission()) return
        val notification = NotificationCompat.Builder(context, CHANNEL_UPDATES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setContentIntent(screenIntent(DESTINATION_UPDATE, REQUEST_UPDATE))
            .addAction(
                0,
                context.getString(R.string.notification_update_skip),
                skipIntent(version)
            )
            .setAutoCancel(true)
            .build()
        runCatching {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_UPDATE, notification)
        }
    }

    /** Unlike [notifyUpdate], this one means the APK is on the device and verified. */
    @SuppressLint("MissingPermission")
    fun notifyUpdateReady(message: String) {
        if (!hasPermission()) return
        val notification = NotificationCompat.Builder(context, CHANNEL_UPDATES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.notification_update_ready_title))
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(screenIntent(DESTINATION_UPDATE, REQUEST_UPDATE_READY))
            .setAutoCancel(true)
            .build()
        runCatching {
            NotificationManagerCompat.from(context)
                .notify(NOTIFICATION_ID_UPDATE_READY, notification)
        }
    }

    private fun skipIntent(version: String): PendingIntent {
        val intent = Intent(context, UpdateSkipReceiver::class.java)
            .putExtra(EXTRA_VERSION, version)
        return PendingIntent.getBroadcast(
            context,
            REQUEST_SKIP,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun screenIntent(destination: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = ACTION_OPEN_DESTINATION
            putExtra(EXTRA_DESTINATION, destination)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun hasPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED

    fun createChannels() {
        val manager = NotificationManagerCompat.from(context)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_TRANSFERS,
                context.getString(R.string.notification_channel_transfers),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.notification_channel_transfers_desc)
            }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_BACKUP,
                context.getString(R.string.notification_channel_backup),
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = context.getString(R.string.notification_channel_backup_desc) }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_UPDATES,
                context.getString(R.string.notification_channel_updates),
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = context.getString(R.string.notification_channel_updates_desc) }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_FAILURES,
                context.getString(R.string.notification_channel_failures),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = context.getString(R.string.notification_channel_failures_desc) }
        )
    }

    companion object {
        const val ACTION_OPEN_DESTINATION = "com.adnan.memoracloud.OPEN"
        const val EXTRA_DESTINATION = "destination"
        const val EXTRA_VERSION = "version"
        const val DESTINATION_TRANSFERS = NotificationDestinations.TRANSFERS
        const val DESTINATION_FILES = NotificationDestinations.FILES
        const val DESTINATION_NOTE = NotificationDestinations.NOTE
        const val DESTINATION_UPDATE = NotificationDestinations.UPDATE
        private const val REQUEST_FAILURE = 1
        private const val REQUEST_BACKUP = 2
        private const val REQUEST_QUEUE = 3
        private const val REQUEST_UPDATE = 4
        private const val REQUEST_SKIP = 5
        private const val REQUEST_UPDATE_READY = 6
        const val CHANNEL_TRANSFERS = "transfers"
        const val CHANNEL_BACKUP = "backup"
        const val CHANNEL_FAILURES = "failures"
        const val CHANNEL_UPDATES = "updates"
        const val NOTIFICATION_ID_TRANSFER_QUEUE = 1001
        const val NOTIFICATION_ID_BACKUP = 1002
        const val NOTIFICATION_ID_FAILURE = 1003
        const val NOTIFICATION_ID_UPDATE = 1004
        const val NOTIFICATION_ID_PUBLISH = 1005
        const val NOTIFICATION_ID_UPDATE_READY = 1006
    }
}
