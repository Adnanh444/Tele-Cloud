package com.adnan.memoracloud.core.transfer

import com.adnan.memoracloud.core.network.NetworkMonitor
import com.adnan.memoracloud.core.network.NetworkStatus
import com.adnan.memoracloud.core.power.PowerMonitor
import com.adnan.memoracloud.data.local.dao.FileDao
import com.adnan.memoracloud.data.local.dao.TransferDao
import com.adnan.memoracloud.data.local.entity.TransferEntity
import com.adnan.memoracloud.domain.model.BackupState
import com.adnan.memoracloud.domain.model.TransferState
import com.adnan.memoracloud.domain.model.TransferType
import com.adnan.memoracloud.domain.model.UserPreferences
import com.adnan.memoracloud.domain.repository.SettingsRepository
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** Transient failures retry with exponential backoff; rate limits wait the server-given delay. */
class TransferQueueDrainer(
    private val transferDao: TransferDao,
    private val fileDao: FileDao,
    private val transferExecutor: TransferExecutor,
    private val backupSessionTracker: BackupSessionTracker,
    private val settingsRepository: SettingsRepository,
    private val networkMonitor: NetworkMonitor,
    private val powerMonitor: PowerMonitor,
    private val backupResumeScheduler: BackupResumeScheduler
) {

    private val claimLock = Mutex()
    private val executing = mutableMapOf<String, TransferType>()

    suspend fun drain(
        isStopped: () -> Boolean,
        onTerminalFailure: suspend (TransferEntity) -> Unit
    ): TransferDrainResult {
        var interrupted = false
        var backupsHeld = false

        // A process killed mid-upload leaves rows in RUNNING that the queue can never claim again.
        runCatching {
            val now = System.currentTimeMillis()
            transferDao.resetStaleRunning(now - STALE_RUNNING_MS, now)
        }

        coroutineScope {
            List(MAX_CONCURRENCY) { slot ->
                launch {
                    while (true) {
                        if (isStopped()) {
                            interrupted = true
                            return@launch
                        }
                        val prefs = settingsRepository.preferences.first()
                        // Checked before claiming the next item, never mid-transfer: the file that
                        // is already uploading runs to completion.
                        if (prefs.queuePaused) return@launch
                        if (slot >= concurrencyOf(prefs)) {
                            if (!awaitSlot(slot)) return@launch
                            continue
                        }
                        val status = networkMonitor.currentStatus()
                        val blocked = status == NetworkStatus.UNAVAILABLE ||
                                (status == NetworkStatus.METERED && !prefs.allowMeteredTransfers)
                        if (blocked) {
                            interrupted = true
                            return@launch
                        }
                        val hold = BackupGate.hold(prefs, status, powerMonitor.isCharging())
                        val next = claimNextQueued(includeBackups = hold == null)
                        if (next == null) {
                            if (hold != null && transferDao.hasQueued(TransferType.BACKUP)) {
                                backupsHeld = true
                            }
                            if (othersBusy()) {
                                delay(IDLE_POLL_MS.milliseconds)
                                continue
                            }
                            return@launch
                        }
                        try {
                            runTransfer(next, prefs.transferRetryCount, onTerminalFailure)
                        } finally {
                            withContext(NonCancellable) {
                                claimLock.withLock { executing.remove(next) }
                            }
                        }
                    }
                }
            }.joinAll()
        }
        if (backupsHeld) scheduleResume()
        if (interrupted) {
            withContext(NonCancellable) { transferDao.requeueRunning() }
            return TransferDrainResult.INTERRUPTED
        }
        return TransferDrainResult.COMPLETED
    }

    suspend fun hasRunnableWork(): Boolean {
        val prefs = settingsRepository.preferences.first()
        val hold = currentHold(prefs)
        if (nextClaimable(includeBackups = hold == null) != null) return true
        if (hold != null && transferDao.hasQueued(TransferType.BACKUP)) scheduleResume()
        return false
    }

    private fun currentHold(prefs: UserPreferences) =
        BackupGate.hold(prefs, networkMonitor.currentStatus(), powerMonitor.isCharging())

    private suspend fun scheduleResume() {
        val prefs = settingsRepository.preferences.first()
        backupResumeScheduler.resumeWhen(prefs.backupChargingOnly, prefs.backupWifiOnly)
    }

    private fun concurrencyOf(prefs: UserPreferences): Int =
        prefs.transferConcurrency.coerceIn(1, MAX_CONCURRENCY)

    /**
     * Raising the setting wakes a parked slot at once; returns false once the queue drains so the
     * slot can finish.
     */
    private suspend fun awaitSlot(slot: Int): Boolean {
        val widened = withTimeoutOrNull(SLOT_WAIT_MS.milliseconds) {
            settingsRepository.preferences.first { slot < concurrencyOf(it) }
        }
        if (widened != null) return true
        val hold = currentHold(settingsRepository.preferences.first())
        return nextClaimable(includeBackups = hold == null) != null
    }

    private suspend fun nextClaimable(
        includeBackups: Boolean,
        skip: Set<String> = emptySet(),
        includeUploads: Boolean = true
    ): TransferEntity? {
        val types = TransferType.entries.filter { type ->
            (includeBackups || type != TransferType.BACKUP) &&
                    (includeUploads || type.isIncoming)
        }
        if (types.isEmpty()) return null
        return transferDao.nextQueuedOf(types, skip.size + 1).firstOrNull { it.id !in skip }
    }

    private suspend fun claimNextQueued(includeBackups: Boolean): String? = claimLock.withLock {
        val uploading = executing.values.any { !it.isIncoming }
        val next = nextClaimable(includeBackups, executing.keys, includeUploads = !uploading)
            ?: return@withLock null
        transferDao.setState(next.id, TransferState.RUNNING, System.currentTimeMillis())
        executing[next.id] = next.type
        next.id
    }

    private suspend fun othersBusy(): Boolean = claimLock.withLock { executing.isNotEmpty() }

    private suspend fun runTransfer(
        transferId: String,
        maxRetries: Int,
        onTerminalFailure: suspend (TransferEntity) -> Unit
    ) {
        var attempt = 0
        while (true) {
            val current = transferDao.byId(transferId) ?: return
            if (current.state != TransferState.RUNNING) return

            when (val outcome = transferExecutor.execute(current)) {
                is TransferOutcome.Completed -> {
                    refreshSession(current.backupSessionId)
                    return
                }

                is TransferOutcome.Paused -> {
                    markState(transferId, TransferState.PAUSED)
                    return
                }

                is TransferOutcome.Abandoned -> {
                    withContext(NonCancellable) {
                        transferDao.setFailed(
                            transferId,
                            TransferState.CANCELLED,
                            outcome.message,
                            System.currentTimeMillis()
                        )
                        current.fileId?.let { fileId ->
                            fileDao.setBackupStateIfLocalOnly(fileId, BackupState.FAILED)
                        }
                    }
                    refreshSession(current.backupSessionId)
                    return
                }

                is TransferOutcome.Canceled -> {
                    markState(transferId, TransferState.CANCELLED)
                    refreshSession(current.backupSessionId)
                    return
                }

                is TransferOutcome.Failed -> {
                    attempt++
                    if (attempt > maxRetries) {
                        withContext(NonCancellable) {
                            transferDao.setFailed(
                                transferId,
                                TransferState.FAILED,
                                outcome.message,
                                System.currentTimeMillis()
                            )
                            current.fileId?.let { fileId ->
                                fileDao.setBackupStateIfLocalOnly(fileId, BackupState.FAILED)
                            }
                            onTerminalFailure(current)
                        }
                        refreshSession(current.backupSessionId)
                        return
                    }
                    val backoffSeconds = outcome.retryAfterSeconds
                        ?: (BASE_BACKOFF_SECONDS shl (attempt - 1)).coerceAtMost(MAX_BACKOFF_SECONDS)
                    delay((backoffSeconds * 1000L).milliseconds)
                }
            }
        }
    }

    private suspend fun refreshSession(sessionId: String?) {
        withContext(NonCancellable) { backupSessionTracker.refresh(sessionId) }
    }

    private suspend fun markState(transferId: String, state: TransferState) {
        withContext(NonCancellable) {
            transferDao.setState(transferId, state, System.currentTimeMillis())
        }
    }

    private companion object {
        const val MAX_CONCURRENCY = 6
        const val SLOT_WAIT_MS = 5_000L
        const val IDLE_POLL_MS = 1_000L
        const val STALE_RUNNING_MS = 15L * 60 * 1000
        const val BASE_BACKOFF_SECONDS = 2
        const val MAX_BACKOFF_SECONDS = 300
    }
}
