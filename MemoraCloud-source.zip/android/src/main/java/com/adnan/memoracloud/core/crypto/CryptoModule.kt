package com.adnan.memoracloud.core.crypto

import com.adnan.memoracloud.core.telegram.TdlibDatabaseKeyProvider
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module

val cryptoModule = module {
    singleOf(::StreamCrypto)
    singleOf(::PassphraseKdf)
    singleOf(::KeyBackupCodec)
    singleOf(::SecureFileDeleter)
    singleOf(::KeystoreManager) bind CredentialCipher::class
    singleOf(::FileWrappedKeyRepository) bind WrappedKeyRepository::class
    singleOf(::TdlibDatabaseKeyProviderImpl) bind TdlibDatabaseKeyProvider::class
}
