package com.adnan.memoracloud.core.update

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.adnan.memoracloud.R
import com.adnan.memoracloud.core.common.AppNotifications
import com.adnan.memoracloud.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.first

/**
 * Only notifies; tapping opens the app, which checks again, so release notes never come from a
 * stale copy.
 */
class UpdateCheckWorker(
    appContext: Context,
    params: WorkerParameters,
    private val updateChecker: UpdateChecker,
    private val settingsRepository: SettingsRepository,
    private val appNotifications: AppNotifications
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val prefs = settingsRepository.preferences.first()
        if (!prefs.onboardingComplete || !prefs.updateCheckEnabled) return Result.success()

        val release = updateChecker.newerRelease()
        settingsRepository.update { it.copy(lastUpdateCheckAt = System.currentTimeMillis()) }
        if (release == null) return Result.success()
        if (release.version == prefs.notifiedUpdateVersion) return Result.success()
        if (release.version == prefs.skippedUpdateVersion) return Result.success()

        appNotifications.createChannels()
        appNotifications.notifyUpdate(
            title = applicationContext.getString(R.string.notification_update_title),
            message = applicationContext.getString(
                R.string.notification_update_message,
                applicationContext.getString(R.string.app_name),
                release.version
            ),
            version = release.version
        )
        settingsRepository.update { it.copy(notifiedUpdateVersion = release.version) }
        return Result.success()
    }

    companion object {
        const val UNIQUE_NAME = "update-check"
    }
}
