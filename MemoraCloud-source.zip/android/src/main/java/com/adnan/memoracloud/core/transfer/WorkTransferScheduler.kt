package com.adnan.memoracloud.core.transfer

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkInfo
import androidx.work.WorkManager

class WorkTransferScheduler(
    private val context: Context
) : TransferScheduler {

    /**
     * A request keeps its constraints for life, so anything not running is replaced, or Wi-Fi only
     * work would keep waiting after mobile data is allowed.
     */
    override fun kick(allowMetered: Boolean) {
        val workManager = WorkManager.getInstance(context)
        val pending = workManager.getWorkInfosForUniqueWork(TransferQueueWorker.UNIQUE_NAME)
        pending.addListener(
            {
                val states = runCatching { pending.get() }
                    .getOrNull()
                    .orEmpty()
                    .map { it.state }
                enqueue(
                    allowMetered = allowMetered,
                    policy = when {
                        WorkInfo.State.BLOCKED in states -> ExistingWorkPolicy.KEEP
                        WorkInfo.State.RUNNING in states -> ExistingWorkPolicy.APPEND_OR_REPLACE
                        else -> ExistingWorkPolicy.REPLACE
                    },
                    expedited = true
                )
            },
            Runnable::run
        )
    }

    override fun rekick(allowMetered: Boolean) {
        enqueue(allowMetered, ExistingWorkPolicy.REPLACE, expedited = false)
    }

    private fun enqueue(
        allowMetered: Boolean,
        policy: ExistingWorkPolicy,
        expedited: Boolean
    ) {
        val request = OneTimeWorkRequestBuilder<TransferQueueWorker>()
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(
                        if (allowMetered) NetworkType.CONNECTED else NetworkType.UNMETERED
                    )
                    .build()
            )
            .apply {
                if (expedited) setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            }
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            TransferQueueWorker.UNIQUE_NAME,
            policy,
            request
        )
    }
}
