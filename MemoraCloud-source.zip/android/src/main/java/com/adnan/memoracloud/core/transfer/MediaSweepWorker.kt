package com.adnan.memoracloud.core.transfer

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.adnan.memoracloud.core.common.AppResult
import com.adnan.memoracloud.core.common.SafeLog
import com.adnan.memoracloud.core.telegram.TelegramAuthState
import com.adnan.memoracloud.domain.model.BackupTrigger
import com.adnan.memoracloud.domain.repository.BackupRepository
import com.adnan.memoracloud.domain.repository.SettingsRepository
import com.adnan.memoracloud.domain.repository.TelegramAuthRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration.Companion.milliseconds

/**
 * The system batches media trigger jobs and can drop a replaced one, so this hourly sweep also
 * re-arms the trigger.
 */
class MediaSweepWorker(
    appContext: Context,
    params: WorkerParameters,
    private val backupRepository: BackupRepository,
    private val telegramAuthRepository: TelegramAuthRepository,
    private val settingsRepository: SettingsRepository,
    private val mediaTriggerScheduler: MediaTriggerScheduler
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val prefs = settingsRepository.preferences.first()
        if (!prefs.autoBackupEnabled) return Result.success()

        if (prefs.instantBackupEnabled) mediaTriggerScheduler.schedule()

        val started = telegramAuthRepository.startFromStoredCredentials()
        if (started is AppResult.Failure || started.getOrNull() != true) return Result.success()

        val ready = withTimeoutOrNull(AUTH_TIMEOUT_MS.milliseconds) {
            telegramAuthRepository.authState.first { it == TelegramAuthState.Ready }
        } != null
        if (!ready) return Result.retry()

        backupRepository.startBackup(BackupTrigger.AUTOMATIC)
        SafeLog.d(TAG, "Hourly backup sweep finished")
        return Result.success()
    }

    companion object {
        private const val TAG = "MediaSweepWorker"
        private const val AUTH_TIMEOUT_MS = 45_000L
        const val UNIQUE_NAME = "media_sweep"
    }
}
