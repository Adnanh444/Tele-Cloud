package com.adnan.memoracloud.data.local

import com.adnan.memoracloud.domain.model.FileQuerySpec

import com.adnan.memoracloud.domain.model.FileCategory
import com.adnan.memoracloud.domain.model.FileSortField
import com.adnan.memoracloud.domain.model.SortDirection
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FileQueryBuilderTest {

    @Test
    fun `default spec hides trashed hidden and archived`() {
        val sql = FileQueryBuilder.build(FileQuerySpec()).sql
        assertTrue(sql.contains("trashedAt IS NULL"))
        assertTrue(sql.contains("isHidden = 0"))
        assertTrue(sql.contains("isArchived = 0"))
    }

    @Test
    fun `folder filter distinguishes root from unfiltered`() {
        val unfiltered = FileQueryBuilder.build(FileQuerySpec(filterByFolder = false)).sql
        assertFalse(unfiltered.contains("AND folderId IS NULL"))
        assertFalse(unfiltered.contains("folderId = ?"))

        val root = FileQueryBuilder.build(
            FileQuerySpec(filterByFolder = true, folderId = null)
        ).sql
        assertTrue(root.contains("AND folderId IS NULL"))

        val specific = FileQueryBuilder.build(
            FileQuerySpec(filterByFolder = true, folderId = "abc")
        ).sql
        assertTrue(specific.contains("folderId = ?"))
    }

    @Test
    fun `contents of hidden and archived folders are excluded unless shown`() {
        val sql = FileQueryBuilder.build(FileQuerySpec()).sql
        assertTrue(sql.startsWith("WITH RECURSIVE"))
        assertTrue(sql.contains("folderId NOT IN (SELECT id FROM hidden_folders)"))
        assertTrue(sql.contains("folderId NOT IN (SELECT id FROM archived_folders)"))

        val shown = FileQueryBuilder.build(
            FileQuerySpec(showHidden = true, showArchived = true)
        ).sql
        assertFalse(shown.contains("hidden_folders"))
        assertFalse(shown.contains("archived_folders"))
    }

    @Test
    fun `category filter uses placeholders`() {
        val sql = FileQueryBuilder.build(
            FileQuerySpec(categories = listOf(FileCategory.IMAGE, FileCategory.VIDEO))
        ).sql
        assertTrue(sql.contains("category IN (?,?)"))
    }

    @Test
    fun `name query escapes like wildcards`() {
        val query = FileQueryBuilder.build(
            FileQuerySpec(nameQuery = "100%_done")
        )
        assertTrue(query.sql.contains("ESCAPE"))
    }

    @Test
    fun `sort direction and field are applied`() {
        val sql = FileQueryBuilder.build(
            FileQuerySpec(
                sortField = FileSortField.SIZE,
                sortDirection = SortDirection.DESCENDING
            )
        ).sql
        assertTrue(sql.contains("ORDER BY sizeBytes DESC"))
    }

    @Test
    fun `backup filters are mutually exclusive clauses`() {
        val backed = FileQueryBuilder.build(FileQuerySpec(backedUpOnly = true)).sql
        assertTrue(backed.contains("backupState = 'BACKED_UP'"))
        val notBacked = FileQueryBuilder.build(FileQuerySpec(notBackedUpOnly = true)).sql
        assertTrue(notBacked.contains("backupState != 'BACKED_UP'"))
    }
}
