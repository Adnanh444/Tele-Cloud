package com.adnan.memoracloud.data.repository

import com.adnan.memoracloud.core.telegram.MessageChange
import com.adnan.memoracloud.core.telegram.RemoteDocument
import com.adnan.memoracloud.core.telegram.RemoteDocumentPage
import com.adnan.memoracloud.core.telegram.TelegramClient
import com.adnan.memoracloud.core.telegram.TelegramDownloadEvent
import com.adnan.memoracloud.core.telegram.TelegramUploadEvent
import com.adnan.memoracloud.data.remote.telegram.IndexSnapshotFile
import com.adnan.memoracloud.data.remote.telegram.RemoteFolderState
import com.adnan.memoracloud.testing.unused
import java.io.File
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.serialization.json.Json

internal class FakeTelegram : TelegramClient by unused() {
    var documents: List<RemoteDocument> = emptyList()
    val editedCaptions = mutableMapOf<Long, String>()
    val uploads = mutableListOf<Pair<String, String>>()
    val deletedMessages = mutableListOf<Long>()
    var failDownloads = false
    val changes = MutableSharedFlow<MessageChange>(extraBufferCapacity = 1_000)
    var openedChats = 0
    var closedChats = 0
    private var nextMessageId = 2_000_000L
    var uploadDateSeconds = 100
    var onFetch: suspend (fromMessageId: Long) -> Unit = {}
    private val stateFiles = mutableListOf<File>()
    private var folderStateDocument: RemoteDocument? = null
    private var folderStateFile: File? = null
    private val storedFiles = mutableMapOf<RemoteDocument, File>()

    fun publishFolderState(state: RemoteFolderState, messageId: Long = 1_000_000) {
        val file = File.createTempFile("folders", ".json").also { stateFiles += it }
        file.writeText(Json.encodeToString(RemoteFolderState.serializer(), state))
        folderStateFile = file
        folderStateDocument = RemoteDocument(
            chatId = TEST_CHAT,
            messageId = messageId,
            remoteFileId = "folder-state",
            uniqueFileId = "folder-state-$messageId",
            fileName = RemoteFolderState.FILE_NAME,
            mimeType = "application/json",
            sizeBytes = file.length(),
            caption = RemoteFolderState.MARKER,
            dateSeconds = 100
        )
    }

    fun addOlderFolderState(json: String, messageId: Long, dateSeconds: Int) {
        val file = File.createTempFile("folders", ".json").also { stateFiles += it }
        file.writeText(json)
        storedFiles[
            RemoteDocument(
                chatId = TEST_CHAT,
                messageId = messageId,
                remoteFileId = "folder-state-$messageId",
                uniqueFileId = "folder-state-$messageId",
                fileName = RemoteFolderState.FILE_NAME,
                mimeType = "application/json",
                sizeBytes = file.length(),
                caption = RemoteFolderState.MARKER,
                dateSeconds = dateSeconds
            )
        ] = file
    }

    fun publishRawFolderState(json: String, messageId: Long = 1_000_000) {
        publishFolderState(RemoteFolderState(), messageId)
        folderStateFile!!.writeText(json)
    }

    override suspend fun ensureStorageChat(knownChatId: Long?): Long = TEST_CHAT

    override suspend fun fetchDocuments(
        chatId: Long,
        fromMessageId: Long,
        limit: Int
    ): RemoteDocumentPage {
        onFetch(fromMessageId)
        val newestFirst = (documents + listOfNotNull(folderStateDocument) + storedFiles.keys)
            .sortedByDescending { it.messageId }
            .filter { fromMessageId == 0L || it.messageId < fromMessageId }
            .take(limit)
        return RemoteDocumentPage(
            documents = newestFirst,
            nextFromMessageId = newestFirst.lastOrNull()?.messageId ?: 0L
        )
    }

    fun uploadedFolderState(): RemoteFolderState = Json { ignoreUnknownKeys = true }
        .decodeFromString(
            RemoteFolderState.serializer(),
            uploads.last { it.first == RemoteFolderState.FILE_NAME }.second
        )

    override fun uploadDocument(
        chatId: Long,
        localPath: String,
        fileName: String,
        mimeType: String,
        caption: String,
        thumbnailPath: String?
    ): Flow<TelegramUploadEvent> {
        val content = File(localPath).readText()
        uploads += fileName to content
        val messageId = nextMessageId++
        val uploaded = RemoteDocument(
            chatId = chatId,
            messageId = messageId,
            remoteFileId = "uploaded-$messageId",
            uniqueFileId = "uploaded-unique-$messageId",
            fileName = fileName,
            mimeType = mimeType,
            sizeBytes = content.length.toLong(),
            caption = caption,
            dateSeconds = uploadDateSeconds
        )
        if (fileName == RemoteFolderState.FILE_NAME) {
            publishRawFolderState(content, messageId)
        }
        if (fileName == IndexSnapshotFile.FILE_NAME) {
            val copy = File.createTempFile("index", ".gz").also { stateFiles += it }
            File(localPath).copyTo(copy, overwrite = true)
            storedFiles[uploaded] = copy
        }
        return flowOf(TelegramUploadEvent.Completed(uploaded))
    }

    override suspend fun deleteMessages(chatId: Long, messageIds: List<Long>) {
        deletedMessages += messageIds
        storedFiles.keys.removeAll { it.messageId in messageIds }
    }

    override suspend fun getDocument(chatId: Long, messageId: Long): RemoteDocument? =
        (documents + listOfNotNull(folderStateDocument) + storedFiles.keys)
            .firstOrNull { it.messageId == messageId }

    override fun messageChanges(chatId: Long): Flow<MessageChange> = changes

    override suspend fun openChat(chatId: Long) {
        openedChats++
    }

    override suspend fun closeChat(chatId: Long) {
        closedChats++
    }

    override fun downloadDocument(remoteFileId: String): Flow<TelegramDownloadEvent> {
        if (failDownloads) return flowOf()
        val file = storedFiles.entries.firstOrNull { it.key.remoteFileId == remoteFileId }?.value
            ?: folderStateFile
            ?: return flowOf()
        return flowOf(TelegramDownloadEvent.Completed(file.absolutePath, file.length()))
    }

    var onEditCaption: suspend (messageId: Long) -> Unit = {}

    override suspend fun editCaption(chatId: Long, messageId: Long, caption: String) {
        onEditCaption(messageId)
        editedCaptions[messageId] = caption
    }

    fun cleanUp() {
        stateFiles.forEach { it.delete() }
    }
}
