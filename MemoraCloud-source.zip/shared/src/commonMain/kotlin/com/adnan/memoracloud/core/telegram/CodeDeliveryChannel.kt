package com.adnan.memoracloud.core.telegram

enum class CodeDeliveryChannel {
    TELEGRAM_APP,
    SMS,
    SMS_WORD,
    SMS_PHRASE,
    CALL,
    FLASH_CALL,
    MISSED_CALL,
    FRAGMENT,
    FIREBASE,
    EMAIL,
    OTHER
}
