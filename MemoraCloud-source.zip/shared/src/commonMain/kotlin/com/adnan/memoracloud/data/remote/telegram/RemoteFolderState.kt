package com.adnan.memoracloud.data.remote.telegram

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import kotlinx.serialization.json.JsonElement

/**
 * File manifests only carry a folder path, so this keeps empty folders, folder ids and flags across
 * a wipe.
 */
@Serializable
data class RemoteFolderState(
    @SerialName("v") val version: Int = VERSION,
    @SerialName("f") val folders: List<RemoteFolderEntry> = emptyList(),
    @SerialName("d") val deleted: List<RemoteFolderTombstone> = emptyList(),
    @SerialName("ix") val indexMessageId: Long? = null,
    @Transient val extra: Map<String, JsonElement> = emptyMap()
) {

    companion object {
        const val VERSION = 1
        const val FILE_NAME = "memoracloud.folders.json"
        const val MARKER = "#memoracloud-folders"
    }
}
