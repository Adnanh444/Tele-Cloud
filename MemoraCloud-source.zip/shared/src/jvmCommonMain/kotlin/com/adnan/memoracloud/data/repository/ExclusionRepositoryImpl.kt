package com.adnan.memoracloud.data.repository

import com.adnan.memoracloud.core.common.SafeLog
import com.adnan.memoracloud.data.local.dao.ExclusionDao
import com.adnan.memoracloud.data.local.entity.ExclusionEntity
import com.adnan.memoracloud.data.mapper.toDomain
import com.adnan.memoracloud.domain.model.Exclusion
import com.adnan.memoracloud.domain.model.ExclusionType
import com.adnan.memoracloud.domain.repository.ExclusionRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class ExclusionRepositoryImpl(
    private val exclusionDao: ExclusionDao,
    private val activeChannel: ActiveChannel
) : ExclusionRepository {

    override fun observeAll(): Flow<List<Exclusion>> =
        activeChannel.observe().flatMapLatest { chatId ->
            exclusionDao.observeAll(chatId).map { list -> list.map { it.toDomain() } }
        }

    override suspend fun ensureDefaults(chatId: Long) {
        if (exclusionDao.countByType(chatId, ExclusionType.HIDDEN) > 0) return
        exclusionDao.upsert(
            ExclusionEntity(
                id = UUID.randomUUID().toString(),
                chatId = chatId,
                type = ExclusionType.HIDDEN,
                value = HIDDEN_PREFIX,
                enabled = true,
                createdAt = System.currentTimeMillis()
            )
        )
        SafeLog.d(TAG, "Seeded the default hidden-file exclusion")
    }

    override suspend fun getEnabled(): List<Exclusion> =
        exclusionDao.enabled(activeChannel.id()).map { it.toDomain() }

    override suspend fun add(type: ExclusionType, value: String): Exclusion {
        val entity = ExclusionEntity(
            id = UUID.randomUUID().toString(),
            chatId = activeChannel.id(),
            type = type,
            value = value.trim(),
            enabled = true,
            createdAt = System.currentTimeMillis()
        )
        exclusionDao.upsert(entity)
        return entity.toDomain()
    }

    override suspend fun setEnabled(id: String, enabled: Boolean) =
        exclusionDao.setEnabled(id, enabled)

    override suspend fun remove(id: String) = exclusionDao.delete(id)

    private companion object {
        const val TAG = "ExclusionRepository"
        const val HIDDEN_PREFIX = "."
    }
}
