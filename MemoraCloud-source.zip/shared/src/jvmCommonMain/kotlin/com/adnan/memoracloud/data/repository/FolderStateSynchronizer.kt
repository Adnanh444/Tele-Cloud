package com.adnan.memoracloud.data.repository

import com.adnan.memoracloud.core.common.SafeLog
import com.adnan.memoracloud.core.crypto.CryptoKeys
import com.adnan.memoracloud.core.crypto.StreamCrypto
import com.adnan.memoracloud.core.crypto.WrappedKeyRepository
import com.adnan.memoracloud.core.files.AppStoragePaths
import com.adnan.memoracloud.core.telegram.RemoteDocument
import com.adnan.memoracloud.core.telegram.TelegramClient
import com.adnan.memoracloud.core.telegram.TelegramDownloadEvent
import com.adnan.memoracloud.core.telegram.TelegramException
import com.adnan.memoracloud.core.telegram.TelegramUploadEvent
import com.adnan.memoracloud.data.local.dao.FolderDao
import com.adnan.memoracloud.data.local.dao.FolderTombstoneDao
import com.adnan.memoracloud.data.local.entity.FolderEntity
import com.adnan.memoracloud.data.local.entity.FolderTombstoneEntity
import com.adnan.memoracloud.data.remote.telegram.ExtraFields
import com.adnan.memoracloud.data.remote.telegram.FolderStateCodec
import com.adnan.memoracloud.data.remote.telegram.RemoteFolderEntry
import com.adnan.memoracloud.data.remote.telegram.RemoteFolderState
import com.adnan.memoracloud.data.remote.telegram.RemoteFolderTombstone
import com.adnan.memoracloud.domain.repository.SettingsRepository
import java.io.File
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * File captions only carry a folder path, so this document keeps empty folders, ids and flags
 * across a wipe.
 */
class FolderStateSynchronizer(
    private val storagePaths: AppStoragePaths,
    private val telegramClient: TelegramClient,
    private val folderDao: FolderDao,
    private val tombstoneDao: FolderTombstoneDao,
    private val settingsRepository: SettingsRepository,
    private val streamCrypto: StreamCrypto,
    private val wrappedKeyRepository: WrappedKeyRepository,
    private val folderMerger: FolderMerger
) {

    private val mutex = Mutex()

    @Volatile
    var indexMessageId: Long? = null
        private set

    /**
     * A document unreadable without the content key is replaced, since waiting for that key would
     * block every folder change.
     */
    suspend fun push() = mutex.withLock { publish(pointIndexAt = null) }

    suspend fun pointIndexAt(messageId: Long) = mutex.withLock { publish(pointIndexAt = messageId) }

    private suspend fun publish(pointIndexAt: Long?) {
        val chatId = storageChatId()
        val existing = findStateDocuments(chatId)
        var remote: RemoteFolderState? = null
        for (document in existing) {
            when (val read = read(document)) {
                is RemoteFolderRead.Ok -> remote = combined(remote, read.state)
                RemoteFolderRead.Unreadable -> SafeLog.w(TAG, "Folder state unreadable, replacing it")
                RemoteFolderRead.Unavailable -> error("Folder state download failed")
            }
        }
        val state = merged(chatId, remote).copy(
            indexMessageId = pointIndexAt ?: remote?.indexMessageId,
            extra = remote?.extra.orEmpty()
        )
        applyLocally(chatId, state)

        val staging = File(storagePaths.cacheDir, RemoteFolderState.FILE_NAME)
        val payload = FolderStateCodec.encode(state).toByteArray(Charsets.UTF_8)
        val prefs = settingsRepository.preferences.first()
        staging.writeBytes(
            if (prefs.encryptFiles && prefs.keyBackupCreated) seal(payload) else payload
        )
        try {
            telegramClient.uploadDocument(
                chatId = chatId,
                localPath = staging.absolutePath,
                fileName = RemoteFolderState.FILE_NAME,
                mimeType = "application/json",
                caption = RemoteFolderState.MARKER
            ).collect { event ->
                if (event is TelegramUploadEvent.Completed) Unit
            }
            if (existing.isNotEmpty()) {
                telegramClient.deleteMessages(chatId, existing.map { it.messageId })
            }
        } finally {
            staging.delete()
        }
        tombstoneDao.deleteOlderThan(deletionCutoff())
        indexMessageId = state.indexMessageId
    }

    /**
     * Sealed with the content key when encryption is on; older plaintext documents stay readable by
     * the magic header.
     */
    private fun seal(payload: ByteArray): ByteArray {
        val key = wrappedKeyRepository.get(CryptoKeys.CONTENT) ?: return payload
        return MAGIC + streamCrypto.encryptBytes(key, payload)
    }

    private fun unseal(blob: ByteArray): String? {
        if (!blob.copyOfRange(0, minOf(MAGIC.size, blob.size)).contentEquals(MAGIC)) {
            return String(blob, Charsets.UTF_8)
        }
        val key = wrappedKeyRepository.get(CryptoKeys.CONTENT) ?: return null
        return runCatching {
            String(
                streamCrypto.decryptBytes(key, blob.copyOfRange(MAGIC.size, blob.size)),
                Charsets.UTF_8
            )
        }.getOrNull()
    }

    /** Never publishes, so applying other devices' changes cannot echo back. */
    suspend fun pull(): Int = mutex.withLock {
        if (folderDao.pendingPublishCount() > 0) return@withLock 0
        val chatId = storageChatId()
        var remote: RemoteFolderState? = null
        for (document in findStateDocuments(chatId)) {
            val read = read(document) as? RemoteFolderRead.Ok ?: continue
            remote = combined(remote, read.state)
        }
        val found = remote ?: return@withLock 0
        indexMessageId = found.indexMessageId
        applyLocally(chatId, merged(chatId, found))
    }

    private suspend fun read(document: RemoteDocument): RemoteFolderRead {
        var localPath: String? = null
        telegramClient.downloadDocument(document.remoteFileId).collect { event ->
            if (event is TelegramDownloadEvent.Completed) localPath = event.localPath
        }
        val blob = localPath?.let(::File)?.takeIf { it.exists() }?.readBytes()
            ?: return RemoteFolderRead.Unavailable
        val payload = unseal(blob) ?: return RemoteFolderRead.Unreadable
        return runCatching { FolderStateCodec.decode(payload) }
            .fold({ RemoteFolderRead.Ok(it) }, { RemoteFolderRead.Unreadable })
    }

    private fun combined(first: RemoteFolderState?, next: RemoteFolderState): RemoteFolderState =
        if (first == null) {
            next
        } else {
            FolderStateMerge.merge(
                local = first.folders,
                localDeleted = first.deleted,
                remote = next,
                keepDeletionsSince = deletionCutoff()
            ).copy(
                indexMessageId = listOfNotNull(first.indexMessageId, next.indexMessageId).maxOrNull(),
                extra = next.extra + first.extra
            )
        }

    private suspend fun merged(chatId: Long, remote: RemoteFolderState?): RemoteFolderState =
        FolderStateMerge.merge(
            local = folderDao.allFolders(chatId).map { it.toEntry() },
            localDeleted = tombstoneDao.inChat(chatId).map {
                RemoteFolderTombstone(it.id, it.deletedAt)
            },
            remote = remote,
            keepDeletionsSince = deletionCutoff()
        )

    /**
     * Updates instead of REPLACE: REPLACE deletes the row first, and the foreign keys would take
     * its subfolders with it.
     */
    private suspend fun applyLocally(chatId: Long, state: RemoteFolderState): Int {
        var changed = 0
        for (entry in state.folders.sortedBy { depthOf(it, state.folders) }) {
            val existing = folderDao.byId(entry.id)
            if (existing?.chatId != null && existing.chatId != chatId) continue
            if (existing != null && existing.changedAt >= entry.clock &&
                existing.parentId == entry.parentId
            ) continue
            if (existing != null && existing.changedAt >= entry.clock) {
                folderDao.update(existing.copy(parentId = entry.parentId))
                changed++
                continue
            }
            val row = FolderEntity(
                id = entry.id,
                chatId = chatId,
                parentId = entry.parentId,
                name = entry.name,
                isHidden = entry.hidden,
                isArchived = entry.archived,
                isFavorite = entry.favorite,
                isAvailableOffline = existing?.isAvailableOffline == true,
                trashedAt = entry.trashedAt,
                preTrashParentId = entry.preTrashParentId,
                pendingPublish = existing?.pendingPublish == true,
                createdAt = entry.createdAt,
                modifiedAt = entry.modifiedAt,
                changedAt = entry.clock,
                extra = ExtraFields.toText(entry.extra)
            )
            if (existing == null) {
                folderDao.upsert(row)
                SafeLog.d(TAG, "Folder state added folder ${entry.id}")
            } else {
                folderDao.update(row)
            }
            changed++
        }

        tombstoneDao.deleteExcept(chatId, state.deleted.map { it.id })
        tombstoneDao.upsert(
            state.deleted.map { FolderTombstoneEntity(it.id, chatId, it.deletedAt) }
        )
        changed += folderMerger.mergeDuplicates(chatId)
        val all = folderDao.allFolders(chatId)
        for (deletion in state.deleted) {
            val folder = all.firstOrNull { it.id == deletion.id } ?: continue
            if (folder.changedAt > deletion.deletedAt ||
                hasNewerDescendant(folder.id, deletion.deletedAt, all)
            ) {
                SafeLog.d(TAG, "Kept deleted folder ${folder.id}: it changed after the deletion")
                continue
            }
            folderDao.delete(folder.id)
            changed++
        }
        return changed
    }

    private fun hasNewerDescendant(
        folderId: String,
        deletedAt: Long,
        all: List<FolderEntity>
    ): Boolean {
        var frontier = listOf(folderId)
        var guard = 0
        while (frontier.isNotEmpty() && guard++ < MAX_DEPTH) {
            val children = all.filter { it.parentId in frontier || it.preTrashParentId in frontier }
            if (children.any { it.changedAt > deletedAt }) return true
            frontier = children.map { it.id }
        }
        return false
    }

    private fun deletionCutoff(): Long = System.currentTimeMillis() - DELETION_RETENTION_MS

    private fun FolderEntity.toEntry() = RemoteFolderEntry(
        id = id,
        parentId = parentId,
        name = name,
        hidden = isHidden,
        archived = isArchived,
        favorite = isFavorite,
        trashedAt = trashedAt,
        preTrashParentId = preTrashParentId,
        createdAt = createdAt,
        modifiedAt = modifiedAt,
        changedAt = changedAt,
        extra = ExtraFields.fromText(extra)
    )

    private fun depthOf(
        entry: RemoteFolderEntry,
        all: List<RemoteFolderEntry>
    ): Int {
        var depth = 0
        var parentId = entry.parentId
        var guard = 0
        while (parentId != null && guard++ < MAX_DEPTH) {
            depth++
            parentId = all.firstOrNull { it.id == parentId }?.parentId
        }
        return depth
    }

    private suspend fun findStateDocuments(chatId: Long): List<RemoteDocument> {
        val found = mutableListOf<RemoteDocument>()
        var fromMessageId = 0L
        var pages = 0
        var pagesAfterFirst = 0
        while (pages++ < MAX_PAGES) {
            val page = try {
                telegramClient.fetchDocuments(chatId, fromMessageId, PAGE_SIZE)
            } catch (e: TelegramException) {
                SafeLog.w(TAG, "Folder state lookup failed: ${e.code}")
                break
            }
            found += page.documents.filter {
                it.fileName == RemoteFolderState.FILE_NAME ||
                        it.caption.startsWith(RemoteFolderState.MARKER)
            }
            if (found.isNotEmpty() && pagesAfterFirst++ >= EXTRA_PAGES) break
            if (page.nextFromMessageId == 0L) break
            fromMessageId = page.nextFromMessageId
        }
        val newest = found.maxByOrNull { it.messageId } ?: return emptyList()
        return found
            .filter { newest.dateSeconds - it.dateSeconds <= SAME_BURST_SECONDS }
            .sortedByDescending { it.messageId }
    }

    private suspend fun storageChatId(): Long {
        val prefs = settingsRepository.preferences.first()
        val chatId = telegramClient.ensureStorageChat(prefs.storageChatId)
        if (chatId != prefs.storageChatId) {
            settingsRepository.update { it.copy(storageChatId = chatId) }
        }
        return chatId
    }

    companion object {
        private const val TAG = "FolderStateSync"
        private val MAGIC = byteArrayOf(0x54, 0x44, 0x46, 0x53) // "TDFS"
        private const val PAGE_SIZE = 100
        private const val MAX_PAGES = 200
        private const val MAX_DEPTH = 64
        private const val EXTRA_PAGES = 1
        private const val SAME_BURST_SECONDS = 600
        private const val DELETION_RETENTION_MS = 180L * 24 * 60 * 60 * 1000
    }
}
