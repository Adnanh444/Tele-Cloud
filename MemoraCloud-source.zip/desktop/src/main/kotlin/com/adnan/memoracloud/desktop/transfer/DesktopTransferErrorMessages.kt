package com.adnan.memoracloud.desktop.transfer

import com.adnan.memoracloud.core.transfer.TransferErrorMessages
import com.adnan.memoracloud.presentation.common.Formatters
import com.adnan.memoracloud.desktop.resources.Res
import com.adnan.memoracloud.desktop.resources.transfer_error_cache_full
import com.adnan.memoracloud.desktop.resources.transfer_error_decryption_failed
import com.adnan.memoracloud.desktop.resources.transfer_error_destination_full
import com.adnan.memoracloud.desktop.resources.transfer_error_download_ended
import com.adnan.memoracloud.desktop.resources.transfer_error_download_stalled
import com.adnan.memoracloud.desktop.resources.transfer_error_downloaded_missing
import com.adnan.memoracloud.desktop.resources.transfer_error_file_record_missing
import com.adnan.memoracloud.desktop.resources.transfer_error_key_missing
import com.adnan.memoracloud.desktop.resources.transfer_error_local_file_gone
import com.adnan.memoracloud.desktop.resources.transfer_error_no_file_reference
import com.adnan.memoracloud.desktop.resources.transfer_error_no_local_copy
import com.adnan.memoracloud.desktop.resources.transfer_error_no_remote_copy
import com.adnan.memoracloud.desktop.resources.transfer_error_save_failed
import com.adnan.memoracloud.desktop.resources.transfer_error_upload_ended
import com.adnan.memoracloud.desktop.resources.transfer_error_upload_stalled
import com.adnan.memoracloud.desktop.resources.transfer_error_verify_failed
import kotlinx.coroutines.runBlocking
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.getString

class DesktopTransferErrorMessages : TransferErrorMessages {

    override val keyMissing by resource(Res.string.transfer_error_key_missing)

    override val noFileReference by resource(Res.string.transfer_error_no_file_reference)

    override val fileRecordMissing by resource(Res.string.transfer_error_file_record_missing)

    override val noLocalCopy by resource(Res.string.transfer_error_no_local_copy)

    override val localFileGone by resource(Res.string.transfer_error_local_file_gone)

    override val uploadEnded by resource(Res.string.transfer_error_upload_ended)

    override val uploadStalled by resource(Res.string.transfer_error_upload_stalled)

    override val downloadEnded by resource(Res.string.transfer_error_download_ended)

    override val downloadStalled by resource(Res.string.transfer_error_download_stalled)

    override val downloadedMissing by resource(Res.string.transfer_error_downloaded_missing)

    override val noRemoteCopy by resource(Res.string.transfer_error_no_remote_copy)

    override val decryptionFailed by resource(Res.string.transfer_error_decryption_failed)

    override val saveFailed by resource(Res.string.transfer_error_save_failed)

    override val verifyFailed by resource(Res.string.transfer_error_verify_failed)

    override fun destinationFull(neededBytes: Long): String = runBlocking {
        getString(Res.string.transfer_error_destination_full, Formatters.bytes(neededBytes))
    }

    override fun cacheFull(neededBytes: Long): String = runBlocking {
        getString(Res.string.transfer_error_cache_full, Formatters.bytes(neededBytes))
    }

    private fun resource(resource: StringResource) = lazy {
        runBlocking { getString(resource) }
    }
}
